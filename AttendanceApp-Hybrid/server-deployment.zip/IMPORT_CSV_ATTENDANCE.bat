@echo off
echo ========================================
echo CSV ATTENDANCE DATA IMPORT
echo ========================================
echo.
echo This will:
echo 1. Reset all attendance data to zero
echo 2. Import CSV attendance data
echo 3. Update student records
echo.
echo Press any key to continue or Ctrl+C to cancel...
pause >nul
echo.

echo Starting CSV import...
node import-csv-attendance.js

echo.
echo ========================================
echo CSV IMPORT COMPLETED
echo ========================================
echo.
pause