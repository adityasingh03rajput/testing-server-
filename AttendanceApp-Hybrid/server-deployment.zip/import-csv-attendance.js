const https = require('https');
const fs = require('fs');

const AZURE_URL = 'https://adioncode-e5gkh4grbqe4g8b7.centralindia-01.azurewebsites.net';

// Helper function to make HTTP requests
function makeRequest(url, method = 'GET', data = null, timeout = 30000) {
    return new Promise((resolve, reject) => {
        const urlObj = new URL(url);
        
        const options = {
            hostname: urlObj.hostname,
            port: urlObj.port || 443,
            path: urlObj.pathname + urlObj.search,
            method: method,
            timeout: timeout,
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'CSV-Import-Tool'
            }
        };
        
        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', chunk => responseData += chunk);
            res.on('end', () => {
                try {
                    const jsonData = JSON.parse(responseData);
                    resolve({ status: res.statusCode, data: jsonData });
                } catch (e) {
                    resolve({ status: res.statusCode, data: responseData });
                }
            });
        });
        
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('TIMEOUT'));
        });
        
        req.on('error', (error) => {
            reject(error);
        });
        
        if (data) {
            req.write(JSON.stringify(data));
        }
        
        req.end();
    });
}

// Parse CSV data
function parseCSV(csvContent) {
    const lines = csvContent.trim().split('\n');
    const headers = lines[0].split(',');
    
    // Extract date columns (skip first column which is Enrollment No)
    const dateColumns = headers.slice(1);
    
    console.log(`📅 Found ${dateColumns.length} date columns:`);
    dateColumns.forEach((date, index) => {
        console.log(`   ${index + 1}. ${date}`);
    });
    
    const attendanceData = [];
    
    // Process each student row
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const enrollmentNo = values[0];
        
        if (!enrollmentNo) continue;
        
        const studentAttendance = {
            enrollmentNo: enrollmentNo,
            attendance: {}
        };
        
        // Process each date column
        for (let j = 1; j < values.length && j < headers.length; j++) {
            const date = headers[j];
            const status = values[j];
            
            // Convert date format from DD-MMM-YYYY to YYYY-MM-DD
            const convertedDate = convertDateFormat(date);
            
            studentAttendance.attendance[convertedDate] = {
                status: status === 'P' ? 'present' : 'absent',
                marked: status === 'P' || status === '',
                originalValue: status
            };
        }
        
        attendanceData.push(studentAttendance);
    }
    
    return attendanceData;
}

// Convert date from DD-MMM-YYYY to YYYY-MM-DD
function convertDateFormat(dateStr) {
    try {
        // Handle format like "26-Aug-2025"
        const [day, month, year] = dateStr.split('-');
        
        const monthMap = {
            'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
            'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
            'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12'
        };
        
        const monthNum = monthMap[month];
        const dayPadded = day.padStart(2, '0');
        
        return `${year}-${monthNum}-${dayPadded}`;
    } catch (error) {
        console.log(`⚠️  Error converting date: ${dateStr}`);
        return dateStr;
    }
}

// Reset all attendance to zero first
async function resetAllAttendance() {
    console.log('🔄 STEP 1: RESETTING ALL ATTENDANCE TO ZERO');
    console.log('═══════════════════════════════════════════');
    
    try {
        // Get all students
        const studentsResponse = await makeRequest(`${AZURE_URL}/api/students`);
        
        if (studentsResponse.status !== 200 || !studentsResponse.data.students) {
            throw new Error('Failed to fetch students');
        }
        
        const allStudents = studentsResponse.data.students;
        console.log(`📋 Found ${allStudents.length} students to reset`);
        
        let resetCount = 0;
        
        for (const student of allStudents) {
            try {
                const resetData = {
                    studentId: student.enrollmentNo || student._id,
                    studentName: student.name,
                    timerValue: 0,
                    isRunning: false,
                    status: 'absent',
                    enrollmentNo: student.enrollmentNo,
                    semester: student.semester || '1',
                    branch: student.course || 'Unknown',
                    timestamp: Date.now(),
                    wifiConnected: false,
                    resetToZero: true
                };
                
                const resetResponse = await makeRequest(`${AZURE_URL}/api/attendance/update-timer`, 'POST', resetData);
                
                if (resetResponse.status === 200 && resetResponse.data.success) {
                    resetCount++;
                    if (resetCount % 10 === 0) {
                        console.log(`   ✅ Reset ${resetCount}/${allStudents.length} students...`);
                    }
                }
                
                // Small delay to avoid overwhelming server
                await new Promise(resolve => setTimeout(resolve, 50));
                
            } catch (error) {
                console.log(`   ❌ Error resetting ${student.name}: ${error.message}`);
            }
        }
        
        console.log(`✅ Reset completed: ${resetCount}/${allStudents.length} students`);
        return true;
        
    } catch (error) {
        console.log('❌ Error during reset:', error.message);
        return false;
    }
}

// Import attendance data
async function importAttendanceData(attendanceData) {
    console.log('\n📊 STEP 2: IMPORTING CSV ATTENDANCE DATA');
    console.log('═══════════════════════════════════════════');
    
    let totalRecords = 0;
    let successfulImports = 0;
    let failedImports = 0;
    
    // Count total records to import
    attendanceData.forEach(student => {
        totalRecords += Object.keys(student.attendance).length;
    });
    
    console.log(`📈 Total attendance records to import: ${totalRecords}`);
    console.log(`👥 Students with attendance data: ${attendanceData.length}`);
    
    for (const studentData of attendanceData) {
        console.log(`\n📋 Processing ${studentData.enrollmentNo}...`);
        
        let studentSuccessCount = 0;
        let studentFailCount = 0;
        
        for (const [date, attendance] of Object.entries(studentData.attendance)) {
            try {
                // Only import if student was present (P)
                if (attendance.status === 'present') {
                    const attendanceRecord = {
                        enrollmentNo: studentData.enrollmentNo,
                        date: date,
                        status: 'present',
                        timerValue: 3600, // 1 hour default for present days
                        sessionAttendance: 100, // 100% for present days
                        lectureAttendance: [
                            {
                                subject: 'General',
                                status: 'present',
                                timestamp: new Date(date + 'T09:00:00Z').getTime()
                            }
                        ],
                        wifiHistory: [
                            {
                                connected: true,
                                timestamp: new Date(date + 'T09:00:00Z').getTime(),
                                bssid: 'college-wifi'
                            }
                        ],
                        importedFromCSV: true,
                        importTimestamp: Date.now()
                    };
                    
                    // Try to create attendance record
                    const importResponse = await makeRequest(`${AZURE_URL}/api/attendance/import-record`, 'POST', attendanceRecord);
                    
                    if (importResponse.status === 200 && importResponse.data.success) {
                        studentSuccessCount++;
                        successfulImports++;
                    } else {
                        studentFailCount++;
                        failedImports++;
                    }
                }
                
                // Small delay to avoid overwhelming server
                await new Promise(resolve => setTimeout(resolve, 25));
                
            } catch (error) {
                studentFailCount++;
                failedImports++;
                console.log(`   ❌ Error importing ${date}: ${error.message}`);
            }
        }
        
        console.log(`   ✅ ${studentData.enrollmentNo}: ${studentSuccessCount} imported, ${studentFailCount} failed`);
        
        // Progress update every 10 students
        if ((attendanceData.indexOf(studentData) + 1) % 10 === 0) {
            console.log(`\n📊 Progress: ${attendanceData.indexOf(studentData) + 1}/${attendanceData.length} students processed`);
            console.log(`   ✅ Successful: ${successfulImports}`);
            console.log(`   ❌ Failed: ${failedImports}`);
        }
    }
    
    return { successfulImports, failedImports, totalRecords };
}

// Main import function
async function importCSVAttendance() {
    console.log('🚀 CSV ATTENDANCE DATA IMPORT');
    console.log('═══════════════════════════════════════════');
    console.log(`📅 Import Date: ${new Date().toLocaleDateString()}`);
    console.log(`⏰ Import Time: ${new Date().toLocaleTimeString()}`);
    console.log(`🌐 Server: ${AZURE_URL}\n`);
    
    try {
        // Step 1: Reset all attendance to zero
        const resetSuccess = await resetAllAttendance();
        if (!resetSuccess) {
            console.log('❌ Reset failed, aborting import');
            return;
        }
        
        // Step 2: Read and parse CSV file
        console.log('\n📄 READING CSV FILE');
        console.log('─'.repeat(50));
        
        const csvContent = fs.readFileSync('attendance-data.csv', 'utf8');
        console.log('✅ CSV file read successfully');
        
        const attendanceData = parseCSV(csvContent);
        console.log(`✅ Parsed attendance data for ${attendanceData.length} students`);
        
        // Step 3: Import attendance data
        const importResults = await importAttendanceData(attendanceData);
        
        // Step 4: Final summary
        console.log('\n📊 IMPORT SUMMARY');
        console.log('═══════════════════════════════════════════');
        
        console.log('📈 IMPORT STATISTICS:');
        console.log(`   • Total records processed: ${importResults.totalRecords}`);
        console.log(`   • Successful imports: ${importResults.successfulImports}`);
        console.log(`   • Failed imports: ${importResults.failedImports}`);
        console.log(`   • Success rate: ${((importResults.successfulImports / importResults.totalRecords) * 100).toFixed(1)}%`);
        
        console.log('\n👥 STUDENT STATISTICS:');
        console.log(`   • Students processed: ${attendanceData.length}`);
        
        // Calculate attendance statistics
        let totalPresentDays = 0;
        let totalPossibleDays = 0;
        
        attendanceData.forEach(student => {
            Object.values(student.attendance).forEach(att => {
                totalPossibleDays++;
                if (att.status === 'present') {
                    totalPresentDays++;
                }
            });
        });
        
        console.log(`   • Total present days: ${totalPresentDays}`);
        console.log(`   • Total possible days: ${totalPossibleDays}`);
        console.log(`   • Overall attendance rate: ${((totalPresentDays / totalPossibleDays) * 100).toFixed(1)}%`);
        
        if (importResults.successfulImports === importResults.totalRecords) {
            console.log('\n🎉 ALL ATTENDANCE DATA SUCCESSFULLY IMPORTED! 🎉');
        } else {
            console.log('\n⚠️  IMPORT COMPLETED WITH SOME ERRORS');
            console.log('   Check server logs for detailed error information');
        }
        
        // Step 5: Verify import with sample data
        console.log('\n🔍 VERIFYING IMPORT');
        console.log('─'.repeat(50));
        
        try {
            // Check a few sample students
            const sampleStudents = attendanceData.slice(0, 3);
            
            for (const student of sampleStudents) {
                const verifyResponse = await makeRequest(`${AZURE_URL}/api/attendance/records?enrollmentNo=${student.enrollmentNo}&limit=5`);
                
                if (verifyResponse.status === 200 && verifyResponse.data.success) {
                    const records = verifyResponse.data.records || [];
                    console.log(`✅ ${student.enrollmentNo}: ${records.length} records found`);
                } else {
                    console.log(`❌ ${student.enrollmentNo}: Verification failed`);
                }
            }
            
        } catch (error) {
            console.log('⚠️  Verification error:', error.message);
        }
        
        console.log('\n✨ CSV IMPORT PROCESS COMPLETED! ✨');
        
    } catch (error) {
        console.error('❌ CSV import failed:', error.message);
        console.error(error.stack);
        process.exit(1);
    }
}

// Run the import
importCSVAttendance().catch(error => {
    console.error('❌ Fatal error during CSV import:', error.message);
    process.exit(1);
});