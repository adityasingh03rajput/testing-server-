const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'LetsBunk Server is running!',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// API config endpoint
app.get('/api/config', (req, res) => {
    res.json({
        version: '1.0.0',
        status: 'active',
        server: 'Azure App Service F1',
        timestamp: new Date().toISOString()
    });
});

// Basic student endpoint
app.get('/api/students', (req, res) => {
    res.json({
        success: true,
        students: [],
        message: 'Student endpoint working'
    });
});

// Basic teacher endpoint
app.get('/api/teachers', (req, res) => {
    res.json({
        success: true,
        teachers: [],
        message: 'Teacher endpoint working'
    });
});

app.listen(PORT, () => {
    console.log(`✅ LetsBunk Server running on port ${PORT}`);
    console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`⏰ Started at: ${new Date().toISOString()}`);
});